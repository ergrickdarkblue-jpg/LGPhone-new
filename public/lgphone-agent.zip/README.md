# LGPhone Agent v3.0

## Yeu cau
- Python 3.10+
- ADB (Android Debug Bridge)
- May Android hoac Emulator bat USB Debugging

## Cai dat
```bash
cd python-agent
pip install -r requirements.txt
```

## Chay
```bash
python agent.py
python agent.py --auto-emulator
python agent.py --zip-only
python agent.py --serial emulator-5554
```

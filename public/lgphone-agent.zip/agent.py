#!/usr/bin/env python3
"""LGPhone Agent v3.0 - AI detect real/virtual devices + auto ADB + zip upload"""

import os, sys, json, time, base64, zipfile, io, subprocess, threading, argparse, socket, random
import requests
from pathlib import Path
from datetime import datetime

DEFAULT_SERVER = "https://nyuvpiztruwdmvogtwpz.supabase.co"
DEFAULT_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im55dXZwaXp0cnV3ZG12b2d0d3B6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQwODcyOTYsImV4cCI6MjA5OTY2MzI5Nn0.TTFg4-APnlmGfGmldh2Dqo42cECkgu3JDqa_8A437k4"
ENV_FILE = Path(".env")
POLL_INTERVAL = 2
HEARTBEAT_SECS = 10
ADB = "adb"


def adb(serial, *args, timeout=15):
    cmd = [ADB, "-s", serial] + list(args)
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout)
        out = r.stdout.decode("utf-8", errors="replace").strip()
        err = r.stderr.decode("utf-8", errors="replace").strip()
        return r.returncode, out, err
    except Exception as e:
        return -1, "", str(e)


def adb_devices():
    try:
        r = subprocess.run([ADB, "devices"], capture_output=True, timeout=10)
        lines = r.stdout.decode("utf-8", errors="replace").strip().splitlines()
    except Exception:
        return []
    devs = []
    for line in lines[1:]:
        p = line.split()
        if len(p) >= 2 and p[1] in ("device", "emulator"):
            devs.append({"serial": p[0], "state": p[1]})
    return devs


def get_prop(serial, key):
    _, out, _ = adb(serial, "shell", f"getprop {key}")
    return out.strip().lower()


EMU_SIGNS = [
    ("ro.hardware", ["goldfish", "ranchu", "vbox86", "genymotion", "nox", "bluestacks"]),
    ("ro.product.model", ["sdk", "emulator", "genymotion", "bluestacks", "memu", "nox"]),
    ("ro.product.manufacturer", ["unknown", "generic", "genymotion"]),
    ("ro.kernel.qemu", ["1"]),
    ("ro.product.name", ["sdk", "generic", "emulator"]),
]
REAL_SIGNS = ["ro.boot.serialno", "gsm.sim.state", "ril.serialnumber"]


def detect_device_type(serial):
    score_emu = 0
    score_real = 0
    props = {}
    keys = [
        "ro.hardware", "ro.product.model", "ro.product.manufacturer",
        "ro.build.tags", "ro.build.fingerprint", "ro.kernel.qemu",
        "ro.product.name", "ro.product.brand", "ro.build.version.release",
        "ro.boot.serialno", "gsm.sim.state", "ril.serialnumber",
        "ro.build.characteristics", "ro.secure", "ro.debuggable",
    ]
    for k in keys:
        props[k] = get_prop(serial, k)
    if serial.lower().startswith("emulator-"):
        score_emu += 5
    for pk, bad in EMU_SIGNS:
        v = props.get(pk, "")
        if any(b in v for b in bad):
            score_emu += 2
        elif v and v not in ("", "unknown"):
            score_real += 1
    for k in REAL_SIGNS:
        v = props.get(k, "")
        if v and v not in ("", "unknown", "null"):
            score_real += 2
    if "emulator" in props.get("ro.build.characteristics", ""):
        score_emu += 3
    if props.get("ro.secure") == "1" and props.get("ro.debuggable") == "0":
        score_real += 2
    total = max(score_emu + score_real, 1)
    if score_emu > score_real:
        dtype = "emulator"
        conf = round(score_emu / total * 100)
    else:
        dtype = "phone"
        conf = round(score_real / total * 100)
    brand = props.get("ro.product.brand", "").title()
    model = props.get("ro.product.model", "Unknown").title()
    return {
        "type": dtype, "confidence": conf,
        "model": f"{brand} {model}".strip(),
        "brand": brand,
        "android": props.get("ro.build.version.release", ""),
        "fingerprint": props.get("ro.build.fingerprint", ""),
    }


def take_screenshot(serial):
    r = subprocess.run(
        [ADB, "-s", serial, "exec-out", "screencap", "-p"],
        capture_output=True, timeout=20,
    )
    if r.returncode == 0 and len(r.stdout) > 1000:
        return r.stdout
    adb(serial, "shell", "screencap", "-p", "/sdcard/lg_ss.png")
    r2 = subprocess.run(
        [ADB, "-s", serial, "pull", "/sdcard/lg_ss.png", "/tmp/lg_ss.png"],
        capture_output=True, timeout=15,
    )
    if r2.returncode == 0:
        try:
            with open("/tmp/lg_ss.png", "rb") as f:
                return f.read()
        except Exception:
            pass
    return None


def create_zip(serial, ss_data, info):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("device_info.json", json.dumps(info, ensure_ascii=False, indent=2))
        if ss_data:
            zf.writestr("screenshot.png", ss_data)
    return buf.getvalue()


def upload_device(server, key, serial, agent_id, info, zip_bytes):
    url = f"{server}/functions/v1/register-device"
    payload = {
        "device_id": serial,
        "device_name": info.get("model") or serial,
        "device_type": info.get("type", "phone"),
        "os_version": f"Android {info.get('android', '')}".strip(),
        "ip_address": info.get("ip", ""),
        "metadata": {
            "agent_id": agent_id,
            **{k: info.get(k, "") for k in ("brand", "model", "android", "confidence", "fingerprint")},
        },
    }
    if zip_bytes:
        payload["zip_base64"] = base64.b64encode(zip_bytes).decode()
    try:
        r = requests.post(url, json=payload, headers={"Authorization": f"Bearer {key}"}, timeout=30)
        b = r.json()
        if r.ok and b.get("success"):
            print(f"  [OK] {serial} -> {info.get('model')} ({info.get('type')}, {info.get('confidence')}%)")
            return True
        print(f"  [FAIL] {b}")
        return False
    except Exception as e:
        print(f"  [FAIL] {e}")
        return False


def heartbeat(server, key, serial):
    try:
        requests.post(
            f"{server}/functions/v1/register-device",
            json={"device_id": serial, "device_type": "heartbeat", "status": "online"},
            headers={"Authorization": f"Bearer {key}"},
            timeout=10,
        )
    except Exception:
        pass


def run_game_farm(serial, loops=10):
    for i in range(loops):
        adb(serial, "shell", f"input tap {random.randint(300, 800)} {random.randint(400, 1500)}")
        time.sleep(random.uniform(0.5, 1.5))
        if i % 5 == 0:
            adb(serial, "shell", "input swipe 540 1200 540 600 400")
            time.sleep(0.5)


def run_social_scroll(serial, loops=10):
    for i in range(loops):
        adb(serial, "shell", "input swipe 540 1500 540 400 600")
        time.sleep(random.uniform(1.0, 3.0))
        if random.random() < 0.2:
            x, y = random.randint(200, 800), random.randint(600, 1200)
            adb(serial, "shell", f"input tap {x} {y}")
            time.sleep(0.08)
            adb(serial, "shell", f"input tap {x} {y}")
            time.sleep(0.5)


def run_auto_like(serial, loops=10):
    for i in range(loops):
        x, y = random.randint(200, 800), random.randint(500, 1400)
        adb(serial, "shell", f"input tap {x} {y}")
        time.sleep(0.08)
        adb(serial, "shell", f"input tap {x} {y}")
        time.sleep(random.uniform(1.5, 3.0))
        adb(serial, "shell", "input swipe 540 1400 540 400 500")
        time.sleep(random.uniform(0.5, 1.5))


def run_daily_login(serial, loops=1, package=""):
    if package:
        adb(serial, "shell", f"monkey -p {package} -c android.intent.category.LAUNCHER 1")
    time.sleep(5)
    adb(serial, "shell", "input tap 540 960")
    time.sleep(1)
    adb(serial, "shell", "input tap 540 1400")


AI_TASKS = {
    "game_farm": run_game_farm,
    "social_scroll": run_social_scroll,
    "auto_like": run_auto_like,
    "daily_login": run_daily_login,
}


def execute_command(serial, command, params):
    try:
        if command == "screenshot":
            data = take_screenshot(serial)
            return (
                {"b64": base64.b64encode(data).decode(), "file": f"ss_{int(time.time())}.png"}
                if data else {"error": "failed"}
            )
        elif command == "tap":
            adb(serial, "shell", f"input tap {int(params.get('x', 540))} {int(params.get('y', 960))}")
            return {"ok": True}
        elif command == "swipe":
            adb(serial, "shell", f"input swipe {int(params.get('x1',540))} {int(params.get('y1',1200))} {int(params.get('x2',540))} {int(params.get('y2',400))} {int(params.get('duration',300))}")
            return {"ok": True}
        elif command == "keyevent":
            adb(serial, "shell", f"input keyevent {params.get('keycode', 'KEYCODE_HOME')}")
            return {"ok": True}
        elif command == "input_text":
            text = str(params.get("text", "")).replace(" ", "%s").replace("'", "")
            adb(serial, "shell", f"input text '{text}'")
            return {"ok": True}
        elif command == "screen_on":
            adb(serial, "shell", "input keyevent KEYCODE_WAKEUP")
            return {"ok": True}
        elif command == "screen_off":
            adb(serial, "shell", "input keyevent KEYCODE_POWER")
            return {"ok": True}
        elif command == "unlock":
            adb(serial, "shell", "input keyevent KEYCODE_WAKEUP")
            time.sleep(0.3)
            adb(serial, "shell", "input swipe 540 1600 540 800 300")
            return {"ok": True}
        elif command == "start_app":
            pkg = params.get("package", "")
            if pkg:
                adb(serial, "shell", f"monkey -p {pkg} -c android.intent.category.LAUNCHER 1")
            return {"ok": True}
        elif command == "stop_app":
            pkg = params.get("package", "")
            if pkg:
                adb(serial, "shell", f"am force-stop {pkg}")
            return {"ok": True}
        elif command == "shell":
            _, out, err = adb(serial, "shell", params.get("cmd", ""))
            return {"output": out or err}
        elif command == "list_packages":
            _, out, _ = adb(serial, "shell", "pm list packages -3")
            return {"packages": [l.replace("package:", "").strip() for l in out.splitlines() if l.strip()]}
        elif command == "reset_device":
            adb(serial, "shell", "pm list packages -3 | cut -d: -f2 | xargs -I{} pm uninstall {}")
            return {"ok": True}
        elif command in AI_TASKS:
            loops = int(params.get("loop", params.get("loops", 10)))
            t = threading.Thread(target=AI_TASKS[command], args=(serial, loops), daemon=True)
            t.start()
            return {"ok": True, "message": f"AI task '{command}' started"}
        else:
            return {"error": f"Unknown command: {command}"}
    except Exception as e:
        return {"error": str(e)}


def poll_commands(server, key, serial, stop_ev):
    url_get = f"{server}/functions/v1/device-commands?device_id={serial}&status=pending"
    url_put = f"{server}/functions/v1/device-commands"
    hdrs = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    while not stop_ev.is_set():
        try:
            r = requests.get(url_get, headers=hdrs, timeout=10)
            if r.ok:
                for cmd in r.json().get("commands", []):
                    requests.put(url_put, json={"id": cmd["id"], "status": "running"}, headers=hdrs, timeout=5)
                    result = execute_command(serial, cmd["command"], cmd.get("params") or {})
                    requests.put(url_put, json={"id": cmd["id"], "status": "done", "result": result}, headers=hdrs, timeout=10)
        except Exception:
            pass
        stop_ev.wait(POLL_INTERVAL)


def main():
    parser = argparse.ArgumentParser(description="LGPhone Agent v3.0")
    parser.add_argument("--server", default="")
    parser.add_argument("--anon-key", default="")
    parser.add_argument("--agent-id", default="agent-01")
    parser.add_argument("--auto-emulator", action="store_true")
    parser.add_argument("--zip-only", action="store_true")
    parser.add_argument("--serial", default="")
    args = parser.parse_args()

    env = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()

    if not ENV_FILE.exists():
        env["SERVER_URL"] = args.server or DEFAULT_SERVER
        env["ANON_KEY"] = args.anon_key or DEFAULT_ANON
        env["AGENT_ID"] = args.agent_id
        env["ADB_PATH"] = "adb"
        ENV_FILE.write_text("\n".join(f"{k}={v}" for k, v in env.items()) + "\n", encoding="utf-8")

    server = args.server or env.get("SERVER_URL", DEFAULT_SERVER)
    key = args.anon_key or env.get("ANON_KEY", DEFAULT_ANON)
    agent_id = args.agent_id or env.get("AGENT_ID", "agent-01")
    global ADB
    ADB = env.get("ADB_PATH", "adb")

    print("=" * 55)
    print("  LGPhone Agent v3.0")
    print(f"  Server: {server}")
    print("=" * 55)

    try:
        subprocess.run([ADB, "version"], capture_output=True, timeout=5)
    except FileNotFoundError:
        print("[ERROR] ADB not found in PATH"); sys.exit(1)

    if args.serial:
        devs = [{"serial": args.serial, "state": "device"}]
    elif env.get("DEVICE_SERIAL"):
        devs = [{"serial": env["DEVICE_SERIAL"], "state": "device"}]
    else:
        print("[SCAN] Scanning ADB devices...")
        devs = adb_devices()

    if not devs and args.auto_emulator:
        print("[AUTO] Starting emulator...")
        try:
            avd_r = subprocess.run(["emulator", "-list-avds"], capture_output=True, timeout=10)
            avds = [l.strip() for l in avd_r.stdout.decode("utf-8", errors="replace").splitlines() if l.strip()]
            if avds:
                subprocess.Popen(
                    ["emulator", "-avd", avds[0], "-no-snapshot-load"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                )
                print("[AUTO] Waiting 30s...")
                time.sleep(30)
                devs = adb_devices()
        except Exception:
            pass

    if not devs:
        print("[ERROR] No ADB devices found"); sys.exit(1)

    print(f"[SCAN] Found {len(devs)} device(s)")
    stop_evs = []

    for dev in devs:
        serial = dev["serial"]
        print(f"\n[DEVICE] {serial}")
        print("  [AI] Detecting device type...")
        info = detect_device_type(serial)
        print(f"  [AI] {info['type'].upper()} | {info['model']} | Android {info['android']} | {info['confidence']}%")
        ss = take_screenshot(serial)
        print(f"  [SS] {'OK' if ss else 'failed'}")
        try:
            info["ip"] = socket.gethostbyname(socket.gethostname())
        except Exception:
            info["ip"] = ""
        zb = create_zip(serial, ss, info)
        print(f"  [ZIP] {len(zb) // 1024} KB")
        upload_device(server, key, serial, agent_id, info, zb)

        if args.zip_only:
            fn = f"lgphone_{serial.replace(':', '_')}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.zip"
            with open(fn, "wb") as f:
                f.write(zb)
            print(f"  [ZIP] Saved: {fn}")
            continue

        stop_ev = threading.Event()
        stop_evs.append(stop_ev)
        threading.Thread(target=poll_commands, args=(server, key, serial, stop_ev), daemon=True).start()

        def _hb(s=serial, ev=stop_ev):
            while not ev.is_set():
                heartbeat(server, key, s)
                ev.wait(HEARTBEAT_SECS)
        threading.Thread(target=_hb, daemon=True).start()

    if args.zip_only:
        return

    print("\n[RUN] Agent running. Press Ctrl+C to stop.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[STOP] Shutting down...")
        for ev in stop_evs:
            ev.set()


if __name__ == "__main__":
    main()
